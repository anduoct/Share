""" Neousys CAN bus driver """

__all__ = [
    "NeousysBus",
    "neousys",
]

from can.interfaces.neousys.neousys import NeousysBus
