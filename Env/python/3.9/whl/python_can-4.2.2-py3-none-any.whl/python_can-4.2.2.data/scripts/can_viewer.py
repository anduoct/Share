#!python

"""
See :mod:`can.viewer`.
"""

from can.viewer import main


if __name__ == "__main__":
    main()
