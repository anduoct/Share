#!python

"""
See :mod:`can.logconvert`.
"""

from can.logconvert import main


if __name__ == "__main__":
    main()
