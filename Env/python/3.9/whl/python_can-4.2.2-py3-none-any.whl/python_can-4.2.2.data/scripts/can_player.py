#!python

"""
See :mod:`can.player`.
"""

from can.player import main


if __name__ == "__main__":
    main()
