# Internal diagnostics database.

class InternalDatabase(object):
    """Internal diagnostics database.

    """

    def __init__(self, dids):
        self.dids = dids
