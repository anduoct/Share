class AutosarNodeSpecifics(object):
    """This class collects the AUTOSAR specific information of node that
    is attached to a CAN bus

    AUTOSAR calls such nodes "ECU instances"...
    """
    def __init__(self):
        pass
